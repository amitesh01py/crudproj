from tkinter import Widget
from attr import field
from django import forms
from .models import User
from django.forms import ModelForm
from django.db import models



class UserForm(forms.ModelForm):
    class meta:
        model=User
        fields="__all__"
        Widget={
            'uname':forms.TextInput(attrs={'class':'form-control'}),
              'uemail':forms.EmailInput(attrs={'class':'form-control'}),
                'upassword':forms.TextInput(attrs={'class':'form-control'}),
        }
            